#!/usr/bin/env ruby

require 'optparse'
require 'fileutils'
require 'yaml/store'

options = {}

OptionParser.new do |opts|
  opts.banner = "Usage: #{File.basename $PROGRAM_NAME} [options]"

  opts.on('-f FILE', '--file', 'mail report file') do |f|
    options[:file] = f
  end

  opts.on('-o DIR', '--output-dir', 'output dir') do |o|
    options[:output_dir] = o
  end

  opts.on('-h', '--help', 'Prints this help') do
    puts opts
    exit
  end
end.parse!

def get_failure_table(file)
  table = []
  num = 0
  File.foreach(file).each do |line|
    num += 1 if line.start_with?('+--')
    if num > 0 && num < 4
      table << line.split('|')[1..-2] if line.start_with?('|')
    end
  end
  table
  end

def save_failure_table(table, path)
  commits = table.shift
  mail_store = {}
  commits.each_with_index do |column, index|
    next if column.strip.empty?
    failures = {}
    table.each do |row|
      failures[row[0].strip] = row[index].strip
    end
    mail_store[column.strip] = failures
  end
  store = YAML::Store.new path
  store.transaction do
    store['table'] = mail_store
  end
  end

def get_failure_tables(file, output_dir)
  table = get_failure_table file
  if table.size > 1
    FileUtils.mkdir_p output_dir
    save_failure_table table, File.join(output_dir, 'table.yaml')
  end
  end

get_failure_tables options[:file], options[:output_dir]
